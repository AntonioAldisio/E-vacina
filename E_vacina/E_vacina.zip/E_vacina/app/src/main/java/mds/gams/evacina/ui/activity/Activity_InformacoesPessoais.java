package mds.gams.evacina.ui.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import mds.gams.evacina.R;

public class Activity_InformacoesPessoais extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__informacoes_pessoais);
    }
}